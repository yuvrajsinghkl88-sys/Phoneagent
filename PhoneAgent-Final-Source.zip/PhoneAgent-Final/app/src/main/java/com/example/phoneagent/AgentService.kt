package com.example.phoneagent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.IOException

class AgentService : AccessibilityService() {

    companion object {
        @Volatile var model = "gemini-3.5-flash-lite"
        const val MAX_STEPS = 25
        var instance: AgentService? = null
        var logger: ((String) -> Unit)? = null
        @Volatile var running = false
        @Volatile var stopRequested = false
        private const val SYSTEM = """You control an Android phone for the user by reading the screen and choosing ONE action per turn.
Reply with ONLY a JSON object, no other text. Actions:
{"action":"open_app","name":"YouTube"}
{"action":"click","index":N}
{"action":"type","index":N,"text":"..."}
{"action":"enter"}  (press the keyboard search/send key on the last typed field)
{"action":"scroll","direction":"down"|"up"}
{"action":"back"} {"action":"home"} {"action":"wait"}
{"action":"done","message":"short summary or question for the user"}
Screen lines look like: [index] "text" "description" flags. Indexes change every turn.
Rules: take the shortest path. Do exactly what the task says. Never send messages, publish posts, delete content, make purchases, submit forms, or change account/security settings without stopping and asking the user for confirmation. If confirmation is needed, the task is unclear, risky beyond what was asked, or you are stuck, use done and explain."""
    }

    private val nodes = ArrayList<AccessibilityNodeInfo>()
    private var lastEdit: AccessibilityNodeInfo? = null

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun log(s: String) = logger?.invoke(s)

    fun runTask(task: String, apiKey: String) {
        if (running) { log("Already running"); return }
        if (task.isBlank() || apiKey.isBlank()) { log("Need a task and an API key"); return }
        running = true; stopRequested = false
        log("Started: $task")
        Thread {
            try {
                val messages = JSONArray()
                messages.put(msg("user", "Task: $task\n\nScreen:\n${dump()}"))
                for (step in 1..MAX_STEPS) {
                    if (stopRequested) { log("Stopped."); break }
                    log("Step $step: asking AI...")
                    val reply = callGeminiWithRetry(apiKey, messages)
                    log("Step $step: $reply")
                    messages.put(msg("assistant", reply))
                    val a = try { JSONObject(reply.substring(reply.indexOf('{'), reply.lastIndexOf('}') + 1)) }
                    catch (e: Exception) { log("Could not parse reply"); break }
                    if (a.optString("action") == "done") { log("DONE: " + a.optString("message")); break }
                    val result = execute(a)
                    Thread.sleep(500)
                    trimOld(messages)
                    messages.put(msg("user", "Result: $result\n\nScreen:\n${dump()}"))
                    if (step == MAX_STEPS) log("Reached step limit.")
                }
            } catch (e: Exception) {
                log("Error: ${e.message}")
            } finally { running = false }
        }.start()
    }

    private fun msg(role: String, text: String) = JSONObject().put("role", role).put("content", text)

    private fun trimOld(messages: JSONArray) {
        // Keep the original task plus only the latest six turns to limit latency and token use.
        if (messages.length() <= 8) return
        val first = messages.getJSONObject(0)
        val taskOnly = first.getString("content").substringBefore("\n\nScreen:")
        val recent = ArrayList<JSONObject>()
        for (i in (messages.length() - 6) until messages.length()) {
            recent.add(messages.getJSONObject(i))
        }
        while (messages.length() > 0) messages.remove(messages.length() - 1)
        messages.put(msg("user", taskOnly))
        recent.forEach { messages.put(it) }
    }

    private fun callGeminiWithRetry(apiKey: String, messages: JSONArray): String {
        var last: Exception? = null
        for (attempt in 1..5) {
            if (stopRequested) throw InterruptedException("Stopped")
            try {
                return callGemini(apiKey, messages)
            } catch (e: TemporaryGeminiException) {
                last = e
            } catch (e: IOException) {
                last = e
            }
            if (attempt < 5) {
                val delay = minOf(1000L * (1L shl (attempt - 1)), 12000L)
                log("Temporary Gemini/network error. Retry $attempt/4 in ${delay / 1000}s…")
                var remaining = delay
                while (remaining > 0 && !stopRequested) {
                    val slice = minOf(remaining, 250L)
                    Thread.sleep(slice)
                    remaining -= slice
                }
            }
        }
        throw RuntimeException("Gemini remained temporarily unavailable after 5 attempts: ${last?.message}", last)
    }

    private class TemporaryGeminiException(message: String) : RuntimeException(message)

    private fun callGemini(apiKey: String, messages: JSONArray): String {
        val contents = JSONArray()
        for (i in 0 until messages.length()) {
            val m = messages.getJSONObject(i)
            val role = if (m.getString("role") == "assistant") "model" else "user"
            contents.put(JSONObject().put("role", role)
                .put("parts", JSONArray().put(JSONObject().put("text", m.getString("content")))))
        }
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", contents)
            .put("generationConfig", JSONObject()
                .put("responseMimeType", "application/json")
                .put("maxOutputTokens", 1024))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.connectTimeout = 10000; c.readTimeout = 30000
        c.setRequestProperty("x-goog-api-key", apiKey)
        c.setRequestProperty("content-type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val responseText = stream?.bufferedReader()?.use { it.readText() } ?: "No response body"
            if (code !in 200..299) {
                val detail = try { JSONObject(responseText).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
                throw RuntimeException(when (code) {
                    400 -> "Bad request/model setting: ${detail ?: responseText.take(180)}"
                    401, 403 -> "API key rejected or permission missing: ${detail ?: responseText.take(180)}"
                    404 -> "Model not found or unavailable: ${detail ?: responseText.take(180)}"
                    429 -> throw TemporaryGeminiException("HTTP 429: ${detail ?: responseText.take(180)}")
                    in 500..599 -> throw TemporaryGeminiException("HTTP $code: ${detail ?: responseText.take(180)}")
                    else -> "API HTTP $code: ${detail ?: responseText.take(180)}"
                })
            }
            val root = JSONObject(responseText)
            val candidates = root.optJSONArray("candidates") ?: throw RuntimeException("No candidates returned: ${root.optJSONObject("promptFeedback")?.toString() ?: "empty response"}")
            if (candidates.length() == 0) throw RuntimeException("AI returned no action. Try a shorter task.")
            val parts = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
                ?: throw RuntimeException("AI response had no text parts")
            if (parts.length() == 0) throw RuntimeException("AI response was empty")
            return parts.getJSONObject(0).optString("text").trim()
        } finally {
            c.disconnect()
        }
    }

    private fun dump(): String {
        nodes.clear()
        val root = rootInActiveWindow ?: return "(no screen)"
        val sb = StringBuilder("app=${root.packageName}\n")
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || nodes.size >= 150) return
            if (n.isVisibleToUser) {
                val t = n.text?.toString()?.take(60) ?: ""
                val d = n.contentDescription?.toString()?.take(60) ?: ""
                if (t.isNotEmpty() || d.isNotEmpty() || n.isClickable || n.isEditable || n.isScrollable) {
                    val f = listOfNotNull(
                        if (n.isClickable) "click" else null,
                        if (n.isEditable) "edit" else null,
                        if (n.isScrollable) "scroll" else null
                    ).joinToString(",")
                    sb.append("[${nodes.size}] \"$t\" \"$d\" $f\n")
                    nodes.add(n)
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return sb.toString()
    }

    private fun execute(a: JSONObject): String {
        return try {
            when (a.optString("action")) {
                "open_app" -> openApp(a.optString("name"))
                "click" -> click(a.optInt("index", -1))
                "type" -> {
                    val n = nodes.getOrNull(a.optInt("index", -1)) ?: return "no such index"
                    n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                    val args = Bundle().apply {
                        putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, a.optString("text"))
                    }
                    lastEdit = n
                    if (n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "typed" else "type failed"
                }
                "enter" -> {
                    if (Build.VERSION.SDK_INT >= 30 && lastEdit != null &&
                        lastEdit!!.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) "enter pressed"
                    else "enter failed, try clicking the search/send button"
                }
                "scroll" -> {
                    val n = nodes.firstOrNull { it.isScrollable } ?: return "nothing scrollable"
                    val act = if (a.optString("direction") == "up") AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                    else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                    if (n.performAction(act)) "scrolled" else "scroll failed"
                }
                "back" -> { performGlobalAction(GLOBAL_ACTION_BACK); "back" }
                "home" -> { performGlobalAction(GLOBAL_ACTION_HOME); "home" }
                "wait" -> "waited"
                else -> "unknown action"
            }
        } catch (e: Exception) { "error: ${e.message}" }
    }

    private fun openApp(name: String): String {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(intent, 0)
            .firstOrNull { it.loadLabel(pm).toString().contains(name, ignoreCase = true) }
            ?: return "app '$name' not found"
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return "cannot launch"
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        return "opened ${match.loadLabel(pm)}"
    }

    private fun click(i: Int): String {
        val node = nodes.getOrNull(i) ?: return "no such index"
        var n: AccessibilityNodeInfo? = node
        while (n != null && !n.isClickable) n = n.parent
        if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "clicked"
        val r = Rect(); node.getBoundsInScreen(r)
        val p = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        dispatchGesture(GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 80)).build(), null, null)
        return "tapped by coordinates"
    }
}
