PhoneAgent - starter Android app
1. Open this folder in Android Studio (File > Open), let Gradle sync.
2. Run on a real Android phone (Android 8+), USB debugging on.
3. In the app tap "Enable Accessibility", turn on "Phone Agent".
   (Android 13+: if greyed out, App info > three dots > Allow restricted settings.)
4. Paste your Gemini API key, type or speak a task, tap Run.
Default model: gemini-3.5-flash-lite. You can change the model name in the app. API keys are not saved by the app.
