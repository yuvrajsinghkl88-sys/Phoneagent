package com.example.phoneagent

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var apiKey: EditText
    private lateinit var model: EditText
    private lateinit var command: EditText
    private lateinit var logView: TextView
    private val prefs by lazy { getSharedPreferences("phoneagent", MODE_PRIVATE) }
    private val permissionRequest = 700

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 36, 32, 24) }
        apiKey = EditText(this).apply {
            hint = "Gemini API key (kept in memory only)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        model = EditText(this).apply { hint = "Gemini model"; setText(prefs.getString("model", "gemini-3.5-flash-lite")) }
        command = EditText(this).apply { hint = "Manual task (optional)"; minLines = 2 }
        val accessibility = Button(this).apply {
            text = "1. Enable PhoneAgent Accessibility"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val startVoice = Button(this).apply {
            text = "2. Start Hey PA voice mode"
            setOnClickListener { requestVoicePermissionsAndStart() }
        }
        val stopVoice = Button(this).apply {
            text = "Stop voice listening"
            setOnClickListener { stopService(Intent(this@MainActivity, VoiceService::class.java).setAction(VoiceService.ACTION_STOP)) }
        }
        val run = Button(this).apply {
            text = "Run manual task"
            setOnClickListener { runManualTask() }
        }
        val stopTask = Button(this).apply {
            text = "Stop current task"
            setOnClickListener { AgentService.stopRequested = true; append("Stop requested") }
        }
        logView = TextView(this).apply { textSize = 14f; setPadding(0, 16, 0, 0) }
        val scroll = ScrollView(this).apply { addView(logView) }
        listOf(apiKey, model, command, accessibility, startVoice, stopVoice, run, stopTask).forEach {
            root.addView(it, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        AgentService.logger = { append(it) }
        VoiceService.status = { append(it) }
    }

    private fun requestVoicePermissionsAndStart() {
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), permissionRequest)
        else startVoiceService()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequest) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startVoiceService()
            else toast("Microphone permission is required for Hey PA")
        }
    }

    private fun startVoiceService() {
        val key = apiKey.text.toString().trim()
        if (key.isBlank()) { toast("Enter your Gemini API key first"); return }
        val modelName = model.text.toString().trim().ifBlank { "gemini-3.5-flash-lite" }
        prefs.edit().putString("model", modelName).apply()
        VoiceService.apiKey = key
        VoiceService.modelName = modelName
        AgentService.model = modelName
        AgentService.logger = { append(it) }
        VoiceService.status = { append(it) }
        val i = Intent(this, VoiceService::class.java)
            .setAction(VoiceService.ACTION_START)
            .putExtra(VoiceService.EXTRA_API_KEY, key)
            .putExtra(VoiceService.EXTRA_MODEL, modelName)
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            append("Voice mode starting. Say Hey PA, then your command.")
        } catch (e: Exception) { append("Could not start voice service: ${e.message}") }
    }

    private fun runManualTask() {
        val service = AgentService.instance
        if (service == null) { toast("Enable PhoneAgent Accessibility in Settings first"); return }
        val key = apiKey.text.toString().trim()
        if (key.isBlank()) { toast("Enter your Gemini API key first"); return }
        val modelName = model.text.toString().trim().ifBlank { "gemini-3.5-flash-lite" }
        AgentService.model = modelName
        AgentService.logger = { append(it) }
        service.runTask(command.text.toString(), key)
    }

    private fun append(line: String) { runOnUiThread { logView.append(line + "\n\n") } }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
