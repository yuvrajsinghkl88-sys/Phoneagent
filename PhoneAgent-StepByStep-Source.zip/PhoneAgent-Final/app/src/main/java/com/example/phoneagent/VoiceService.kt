package com.example.phoneagent

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * User-started foreground speech service. Android may still restrict microphone use
 * after the user force-stops the app, revokes permission, or applies vendor battery limits.
 */
class VoiceService : Service(), RecognitionListener {
    companion object {
        const val ACTION_START = "com.example.phoneagent.voice.START"
        const val ACTION_STOP = "com.example.phoneagent.voice.STOP"
        const val EXTRA_API_KEY = "api_key"
        const val EXTRA_MODEL = "model"
        @Volatile var apiKey: String = ""
        @Volatile var modelName: String = "gemini-3.5-flash-lite"
        @Volatile var status: ((String) -> Unit)? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var awaitingCommand = false
    private var handlingResult = false
    private var destroyed = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        tts = TextToSpeech(this) { result -> if (result == TextToSpeech.SUCCESS) tts?.language = Locale("en", "IN") }
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this) }
        } else report("Speech recognition is unavailable on this device")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopListeningService(); return START_NOT_STICKY }
            ACTION_START, null -> {
                intent?.getStringExtra(EXTRA_API_KEY)?.let { if (it.isNotBlank()) apiKey = it }
                intent?.getStringExtra(EXTRA_MODEL)?.let { if (it.isNotBlank()) modelName = it }
                val notification = buildNotification()
                if (Build.VERSION.SDK_INT >= 29) {
                    startForeground(41, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
                } else startForeground(41, notification)
                startListening()
            }
        }
        return START_STICKY
    }

    private fun startListening() {
        if (destroyed || recognizer == null) return
        main.postDelayed({
            if (destroyed || recognizer == null) return@postDelayed
            try {
                handlingResult = false
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                }
                recognizer?.startListening(i)
                report(if (awaitingCommand) "Listening for your command…" else "Listening for Hey PA…")
            } catch (e: Exception) {
                report("Could not start speech recognition: ${e.message}")
                scheduleRestart()
            }
        }, 350)
    }

    override fun onResults(results: Bundle?) {
        if (handlingResult) return
        handlingResult = true
        val phrases = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        val phrase = phrases.firstOrNull()?.trim().orEmpty()
        handlePhrase(phrase)
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val phrase = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
        if (isCancel(phrase)) {
            AgentService.stopRequested = true
            awaitingCommand = false
            report("Current task cancelled by voice")
        }
    }

    private fun handlePhrase(raw: String) {
        val text = normalize(raw)
        if (text.isBlank()) { scheduleRestart(); return }
        if (isCancel(text)) {
            AgentService.stopRequested = true
            awaitingCommand = false
            speak("Stopping the current task")
            report("Stop/Cancel heard — current task stopped")
            scheduleRestart()
            return
        }

        val wake = listOf("hey pa", "hey p a", "हे पी ए", "हे पा", "ए पी ए")
        val found = wake.firstOrNull { text.contains(it) }
        if (awaitingCommand) {
            awaitingCommand = false
            launchTask(raw)
        } else if (found != null) {
            val command = text.substringAfter(found).trim(' ', ',', '.', '!', '?')
            if (command.isNotBlank()) launchTask(command)
            else {
                awaitingCommand = true
                speak("Yes? Tell me what to do")
                report("Wake phrase detected. Speak your command.")
            }
        } else {
            report("Wake phrase not detected")
        }
        scheduleRestart()
    }

    private fun launchTask(command: String) {
        if (apiKey.isBlank()) {
            report("Open PhoneAgent and enter your Gemini API key before starting voice mode")
            speak("Please enter your Gemini API key in PhoneAgent")
            return
        }
        val svc = AgentService.instance
        if (svc == null) {
            report("Enable PhoneAgent Accessibility Service in Android Settings first")
            speak("Please enable PhoneAgent accessibility")
            return
        }
        AgentService.model = modelName
        AgentService.logger = { line -> report(line) }
        if (AgentService.running) {
            report("A task is already running. Say Stop or Cancel first.")
        } else {
            report("Command: $command")
            speak("Working on it")
            svc.runTask(command, apiKey)
        }
    }

    private fun normalize(s: String) = s.lowercase(Locale.ROOT).replace(Regex("\\s+"), " ").trim()
    private fun isCancel(s: String): Boolean {
        val n = normalize(s)
        return Regex("(^|\\b)(stop|cancel|abort|रुको|रोक दो|बंद करो|कैंसल|कैंसल करो)(\\b|$)").containsMatchIn(n)
    }

    private fun speak(s: String) { try { tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "phoneagent_voice") } catch (_: Exception) {} }
    private fun report(s: String) { status?.invoke(s) }
    private fun scheduleRestart() { if (!destroyed) main.postDelayed({ startListening() }, 700) }

    override fun onError(error: Int) {
        if (destroyed) return
        report("Speech recognition paused ($error); restarting…")
        scheduleRestart()
    }
    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onEvent(eventType: Int, params: Bundle?) {}

    private fun stopListeningService() {
        destroyed = true
        try { recognizer?.cancel(); recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        destroyed = true
        try { recognizer?.cancel(); recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        tts?.shutdown(); tts = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("phoneagent_voice", "PhoneAgent voice", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, "phoneagent_voice")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("PhoneAgent is listening")
                .setContentText("Say Hey PA, then your command. Say Stop or Cancel to interrupt.")
                .setContentIntent(open).setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("PhoneAgent is listening")
                .setContentText("Say Hey PA, then your command. Say Stop or Cancel to interrupt.")
                .setContentIntent(open).setOngoing(true).build()
        }
    }
}
